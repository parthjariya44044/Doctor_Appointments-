import "../styles/doctorcard.css";
import React, { useState } from "react";
import BookAppointment from "../components/BookAppointment";
import { toast } from "react-hot-toast";

const DoctorCard = ({ ele }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [token] = useState(sessionStorage.getItem("token") || "");

  const handleModal = () => {
    if (token === "") {
      return toast.error("You must log in first");
    }
    setModalOpen(true);
  };

  return (
    <div className={`card`}>
      <div className={`card-img flex-center`}>
        <img
          src={
            ele?.userId?.pic ||
            "https://icon-library.com/images/anonymous-avatar-icon/anonymous-avatar-icon-25.jpg"
          }
          alt="profile"
        />
      </div>
      <div className="card-details">
        <h3 className="card-name">
          Dr. {ele?.userId?.firstname + " " + ele?.userId?.lastname}
        </h3>
        <div className="card-buttons">
          <div className="role-text">
            {ele?.specialty || ele?.specialization}
          </div>
          <button className="hospital-btn">
            {ele?.hospitals && ele.hospitals.length > 0 
              ? ele.hospitals.join(", ") 
              : "General Hospital"}
          </button>
          <button
            className="btn appointment-btn"
            onClick={handleModal}
          >
            Appointment
          </button>
        </div>
      </div>
      {modalOpen && (
        <BookAppointment
          setModalOpen={setModalOpen}
          ele={ele}
        />
      )}
    </div>
  );
};

export default DoctorCard;
