import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/bookappointment.css";
import axios from "axios";
import toast from "react-hot-toast";
import { IoMdClose } from "react-icons/io";

const BookAppointment = ({ setModalOpen, ele }) => {
  const [formDetails, setFormDetails] = useState({
    date: "",
    time: "",
    name: "",
    age: "",
    height: "",
    weight: "",
    number: "",
    address: "",
    gender: "male",
    diseases: "",
  });

  const navigate = useNavigate();

  const inputChange = (e) => {
    const { name, value } = e.target;
    return setFormDetails({
      ...formDetails,
      [name]: value,
    });
  };

  const bookAppointment = async (e) => {
    e.preventDefault();

    // Validation: Match disease with specialization/specialty
    const spec = (ele?.specialty || ele?.specialization || "").toLowerCase();
    const diseases = formDetails.diseases.toLowerCase();

    // Specific validation rules for common specializations
    if (spec.includes("cancer") && !diseases.includes("cancer")) {
      return toast.error("This doctor only accepts cancer-related cases.");
    }
    
    if (spec.includes("surgeon") && !diseases.includes("surgery") && !diseases.includes("surgical") && !diseases.includes("operation")) {
      return toast.error("This doctor only accepts surgery-related cases.");
    }

    if (spec.includes("eye") && !diseases.includes("eye") && !diseases.includes("vision") && !diseases.includes("sight")) {
      return toast.error("This doctor only accepts eye-related cases.");
    }

    if (spec.includes("skin") && !diseases.includes("skin") && !diseases.includes("rash") && !diseases.includes("acne")) {
      return toast.error("This doctor only accepts skin-related cases.");
    }

    if (spec.includes("heart") && !diseases.includes("heart") && !diseases.includes("cardio") && !diseases.includes("chest")) {
      return toast.error("This doctor only accepts heart-related cases.");
    }

    if ((spec.includes("fever") || spec.includes("general")) && !diseases.includes("fever") && !diseases.includes("general") && !diseases.includes("flu") && !diseases.includes("cold")) {
      return toast.error("This doctor only accepts general health/fever cases.");
    }

    const doctorName = `${ele?.userId?.firstname} ${ele?.userId?.lastname}`;
    const currentDate = new Date().toLocaleDateString();
    const currentTime = new Date().toLocaleTimeString();

    try {
      await toast.promise(
        axios.post(
          "/appointment/bookappointment",
          {
            doctorId: ele?.userId?._id,
            date: currentDate,
            time: currentTime,
            name: formDetails.name,
            age: formDetails.age,
            height: formDetails.height,
            weight: formDetails.weight,
            number: formDetails.number,
            address: formDetails.address,
            gender: formDetails.gender,
            diseases: formDetails.diseases,
            doctorname: doctorName,
          },
          {
            headers: {
              Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            },
          }
        ),
        {
          success: "User successfully complete book appointments",
          error: "Unable to book appointment",
          loading: "Booking appointment...",
        }
      );
      setModalOpen(false);
      navigate("/bookingsuccess", {
        state: {
          doctorName: doctorName,
          appointmentDate: currentDate,
          appointmentTime: currentTime,
        },
      });
    } catch (error) {
      return error;
    }
  };

  return (
    <>
      <div className="modal flex-center">
        <div className="modal__content appointment-modal-content">
          <IoMdClose
            onClick={() => {
              setModalOpen(false);
            }}
            className="close-btn"
          />
          <div className="appointment-container">
            {/* Left Side: Doctor Information */}
            <div className="doctor-info-section">
              <h3>Doctor Information</h3>
              <div className="info-item">
                <strong>Education:</strong> {ele?.education || "MBBS, MD"}
              </div>
              <div className="info-item">
                <strong>Experience:</strong> {ele?.experience} years
              </div>
              <div className="info-item">
                <strong>Hospitals:</strong> {ele?.hospitals?.length > 0 ? ele.hospitals.join(", ") : "General Hospital"}
              </div>
              <div className="info-item">
                <strong>Specialty:</strong> {ele?.specialty || "General"}
              </div>
              <div className="info-item">
                <strong>Specialization:</strong> {ele?.specialization}
              </div>
              <div className="info-item">
                <strong>Fees:</strong> ${ele?.fees}
              </div>
            </div>

            {/* Right Side: Client Form */}
            <div className="client-form-section">
              <h3>Client Details</h3>
              <form className="appointment-form" onSubmit={bookAppointment}>
                <div className="form-grid">
                  <input
                    type="text"
                    name="name"
                    placeholder="Full Name"
                    className="form-input"
                    value={formDetails.name}
                    onChange={inputChange}
                    required
                  />
                  <input
                    type="number"
                    name="age"
                    placeholder="Age"
                    className="form-input"
                    value={formDetails.age}
                    onChange={inputChange}
                    required
                  />
                  <input
                    type="text"
                    name="height"
                    placeholder="Height"
                    className="form-input"
                    value={formDetails.height}
                    onChange={inputChange}
                  />
                  <input
                    type="text"
                    name="weight"
                    placeholder="Weight"
                    className="form-input"
                    value={formDetails.weight}
                    onChange={inputChange}
                  />
                  <input
                    type="number"
                    name="number"
                    placeholder="Mobile Number"
                    className="form-input"
                    value={formDetails.number}
                    onChange={inputChange}
                    required
                  />
                  <input
                    type="text"
                    name="address"
                    placeholder="Address"
                    className="form-input"
                    value={formDetails.address}
                    onChange={inputChange}
                  />
                  <select
                    name="gender"
                    className="form-input"
                    value={formDetails.gender}
                    onChange={inputChange}
                    required
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <textarea
                  name="diseases"
                  placeholder="Type of Diseases"
                  className="form-input"
                  value={formDetails.diseases}
                  onChange={inputChange}
                  required
                ></textarea>
                <button
                  type="submit"
                  className="btn form-btn"
                >
                  Book Appointment
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookAppointment;
